#include "ns3/SimInterface.h"

using namespace ns3;
namespace ns3{

	unsigned int SimInterfaceRequest::unique_id { 0 };

}
