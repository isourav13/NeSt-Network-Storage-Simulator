/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

#include "MQsim.h"

namespace ns3 {

check_hello::check_hello()
{

}

void check_hello::print_something()
{
	printf("Hello World\n");
}
/* ... */


}

