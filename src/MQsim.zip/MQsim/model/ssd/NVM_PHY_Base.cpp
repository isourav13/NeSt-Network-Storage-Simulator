#include "ns3/NVM_PHY_Base.h"
using namespace ns3;

namespace ns3{
namespace SSD_Components
{
	NVM_PHY_Base::NVM_PHY_Base(const sim_object_id_type& id)
		: MQSimEngine::Sim_Object(id)
	{
	}

	NVM_PHY_Base::~NVM_PHY_Base()
	{
	}
}
}
