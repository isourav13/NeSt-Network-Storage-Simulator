#ifndef NVM_CHANNEL_BASE_H
#define NVM_CHANNEL_BASE_H
using namespace ns3;
namespace ns3{
namespace SSD_Components
{
	enum class BusChannelStatus { BUSY, IDLE };
	class NVM_Channel_Base {};
}
}
#endif // !NVM_CHANNEL_BASE_H


