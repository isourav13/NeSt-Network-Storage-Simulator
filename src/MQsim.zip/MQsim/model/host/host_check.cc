#include "host_check.h"

namespace ns3 {

check_hello_host::check_hello_host()
{

}

void check_hello_host::print_something()
{
	printf("Hello World\n");
}
/* ... */


}

