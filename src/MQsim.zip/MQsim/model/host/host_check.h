/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef MQSIM_HOST_H
#define MQSIM_HOST_H
#include "stdio.h"
namespace ns3 {

class check_hello_host
{
public:
	check_hello_host();
	void print_something();
};

/* ... */

}

#endif /* MQSIM_H */

