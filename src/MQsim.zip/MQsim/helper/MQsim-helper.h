/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef MQSIM_HELPER_H
#define MQSIM_HELPER_H

#include "ns3/MQsim.h"

namespace ns3 {

/* ... */

}

#endif /* MQSIM_HELPER_H */

